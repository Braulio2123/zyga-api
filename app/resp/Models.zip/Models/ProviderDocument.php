<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class ProviderDocument extends Model
{
    protected $table = 'provider_documents';

    protected $fillable = [
        'provider_id',
        'document_type',
        'document_url',
    ];

    protected $casts = [
        'provider_id' => 'integer',
    ];

    public function provider(): BelongsTo
    {
        return $this->belongsTo(Provider::class, 'provider_id');
    }
}
